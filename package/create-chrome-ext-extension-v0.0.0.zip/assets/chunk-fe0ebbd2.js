let n;const e=document.querySelector("body"),t=document.createElement("h1");t.textContent="Hello!!";e==null||e.prepend(t);export{n as t};
